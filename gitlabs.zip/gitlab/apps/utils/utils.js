(function(window, initComponents, undefined) {
    codeathon = function() {};
    //make Codeathon global
    window.Codeathon = new codeathon();
})(window, function(Codeathon, window, document) {});

(function(window, initComponents, undefined) {
    utils = function() {};

    utils.prototype.isNullOrEmpty = function(obj) {
        return (angular.isUndefined(obj) || obj == null || obj == 'null' || typeof obj == "undefined" || obj == "");
    };
    

    //make Codeathon global
    window.Codeathon.utils = new utils();
})(window, function(UTILS, window, document) {});
