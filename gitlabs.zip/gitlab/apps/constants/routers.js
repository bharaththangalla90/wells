(function() {
    'use strict';
    fileuploader.constant('uiRouters', {
        filepath: 'apps/datafiles',
        urlpath:'',
	
        directivesHtmlPath: 'apps/views',
        home: '/home/',
        dashboard: '/dashboard/',
        login: '/login/',
    });
})();
