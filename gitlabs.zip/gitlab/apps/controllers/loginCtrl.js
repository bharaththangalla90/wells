(function() {
    'use strict';

    fileuploader.controller("loginCtrl", ['$scope', '$rootScope', 'uiRouters', '$location', '$route', loginCtrl]);

    function loginCtrl($scope, $rootScope, uiRouters, $location, $route) {

        
    }


    
})();
